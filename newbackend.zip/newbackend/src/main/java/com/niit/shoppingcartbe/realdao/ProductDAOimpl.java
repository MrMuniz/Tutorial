package com.niit.shoppingcartbe.realdao;

import java.util.List;

import javax.persistence.Query;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.shoppingcartbe.model.Product;

@Repository("productDAO")
public class ProductDAOimpl implements ProductDAO {

	@Autowired
	private SessionFactory sessionFactory;

	public ProductDAOimpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Transactional
	public void saveOrUpdate(Product product) {
		sessionFactory.getCurrentSession().saveOrUpdate(product);
	}

	@Transactional
	public void delete(String Name) {
		Product product = new Product();
		product.setName(Name);
		sessionFactory.getCurrentSession().delete(product);
	}

	@Transactional
	public Product get(String name) {
		String hql = "from category where id=" + "'" + name + "'";

		Query query = sessionFactory.getCurrentSession().createQuery(hql);
		List<Product> listproduct = (List<Product>) query.getResultList();

		if (listproduct != null && !listproduct.isEmpty()) {
			return listproduct.get(0);
		}
		return null;
	}

	@Transactional
	public List<Product> list() {
		@SuppressWarnings("unchecked")
		List<Product> listProduct = (List<Product>) sessionFactory.getCurrentSession().createCriteria(Product.class)
				.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();
		return listProduct;
	}

}
