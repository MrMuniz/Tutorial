package com.niit.cart.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.cart.dao.SupplierDAO;
import com.niit.cart.model.Supplier;

public class SupplierTest {

	public static void main(String[] args) 
	{
		
AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		
		context.scan("com.niit.cart");
		context.refresh();
	
	
		SupplierDAO supplierDAO = (SupplierDAO) context.getBean("SupplierDAO");
		Supplier supplier = (Supplier) context.getBean("supplier");
		
		supplier.setId("a.a");
		supplier.setName("BMW");
		supplier.setAddress("fast");
	
	
		supplierDAO.saveOrUpdate(supplier);

	}

}
