package com.niit.cart.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.cart.dao.CategoryDAO;
import com.niit.cart.model.Category;


public class CatTest {

	public static void main(String[] args) {

		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		
		context.scan("com.niit.cart");
		context.refresh();
	
	
		CategoryDAO categoryDAO = (CategoryDAO) context.getBean("categoryDAO");
		Category category = (Category) context.getBean("category");
		
		category.setCid("8934");
		category.setCname("BMW");
		category.setCdescription("fast");
	
	
		categoryDAO.saveOrUpdate(category);
		
		
		/*
		if (categoryDAO.get(kjbfk)== null)
		{
			System.out.println("Error Does not exist");
		}
		else 
		{
			System.out.println("Does exist");
		}*/
	}
	
	
	

}
