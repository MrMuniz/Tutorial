package com.practice.work;


import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcartbe.model.Category;
import com.niit.shoppingcartbe.realdao.CategoryDAO;

public class CatTest {

	public static void main(String[] args) {

		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		
		context.scan("com.niit.shoppingcartbe");
		context.refresh();
	
		CategoryDAO categoryDAO = (CategoryDAO) context.getBean("categoryDAO");
		Category category = (Category) context.getBean("category");
		
		category.setCid("572");
		category.setCname("Kawasaki");
		category.setCdescription("need special order");
		categoryDAO.saveOrUpdate(category);
	
	
		
//		/*.args*/
//		/*
//		if (categoryDAO.get(kjbfk)== null)
//		{
//			System.out.println("Error Does not exist");
//		}
//		else 
//		{
//			System.out.println("Does exist");
//		}*/
	
		
		
	
	
	}
}
