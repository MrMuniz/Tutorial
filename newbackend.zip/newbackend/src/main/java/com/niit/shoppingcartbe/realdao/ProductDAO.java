package com.niit.shoppingcartbe.realdao;

import java.util.List;

import com.niit.shoppingcartbe.model.Product;
import com.niit.shoppingcartbe.model.User;

public interface ProductDAO {
	

	public List<Product> list();
	
	public Product get(String Name);
	
	public void saveOrUpdate (Product product);
	
	public void delete(String Name);
	

}
