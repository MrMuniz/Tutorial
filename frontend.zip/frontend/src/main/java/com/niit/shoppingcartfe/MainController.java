package com.niit.shoppingcartfe;



import javax.persistence.Id;
//import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
//import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestMethod;
//import org.springframework.web.bind.annotation.RequestParam;
//import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.niit.shoppingcartbe.model.Category;
import com.niit.shoppingcartbe.model.Supplier;
import com.niit.shoppingcartbe.model.User;
import com.niit.shoppingcartbe.realdao.CategoryDAO;
import com.niit.shoppingcartbe.realdao.SupplierDAO;
import com.niit.shoppingcartbe.realdao.UserDAO;





@Controller
public class MainController 
{
	
	@Id
	@Autowired
	UserDAO userDAO;
	
	@Autowired
	User user;
	
	@Autowired
	Category category;

	@Autowired
	CategoryDAO categoryDAO;
	
	@Autowired
	Supplier supplier;
	
	@Autowired
	SupplierDAO supplierDAO;
	
	
	
//	@RequestMapping("/")
//	public ModelAndView onLoad(HttpSession session) {
//		//log.debug("Starting of the method onLoad");
//		ModelAndView mv = new ModelAndView("/Home");
//		session.setAttribute("category", category);
//		session.setAttribute("categoryList", categoryDAO.list());
//		//log.debug("Ending of the method onLoad");
//		return mv;
//	}

//	@RequestMapping(value = "user/register", method = RequestMethod.POST)
//	public ModelAndView registerUser(@ModelAttribute User user) {
//		userDAO.saveOrUpdate(user);
//		ModelAndView mv = new ModelAndView("/Home");
//		mv.addObject("successMessage", "You are successfully register");
//
//		return mv;
//	}

	@RequestMapping("/")
	public String GetHomelandingpage()
	{
		return "Home";
	}

	@RequestMapping("/Home")
	public String GetHome()
	{
		return "Home";
	}
	
	
	@RequestMapping("/AboutUs")
	public String GetAboutUs()
	{
		return "AboutUs";
	}

	@RequestMapping("/ContactUs")
	public String GetContactUs()
	{
		return "ContactUs";
	}

	@RequestMapping("/SignUp")
	public String GetSignUp()
	{
		return "SignUp";
	}

//	@RequestMapping("/SignUp")
//	public ModelAndView SignUp() {
//		ModelAndView mv = new ModelAndView("/Home");
//		mv.addObject("user", new User());
//		mv.addObject("isUserClickedRegisterHere", "true");
//		return mv;
//	}
	
	
	
	@RequestMapping("/Login")
	public String getLogin()
	{
		return "Login";
	}

		
		@RequestMapping("/check")
		public ModelAndView login(@RequestParam (name="name")String id,@RequestParam (name="password")String password)
		{
			ModelAndView mv = new ModelAndView("/Admin");
			boolean isValidUser = userDAO.isValidUser (id, password);
			if (isValidUser == true)
			{
				user = userDAO.get(id);
				
				if (user.getAdmin()==true)
				{
					mv.addObject("admin", "true");
				}
				else
				{
					mv.addObject("admin", "false");
				}
			}
				else
				{
					mv.addObject("invalid credentials", "true");
					mv.addObject("error Message", "invalid credentials");
				}
			
			return mv;
		}
	
	@RequestMapping("/Touring")
	public String getTouring()
	{
		return "Touring";
	}	
//	
//	@RequestMapping("/SuccessfulSignup")
//	public String GetSuccessfulSign()
//	{
//		return "SuccessfulSignup";
//	}
//
//	@RequestMapping("/SuccessfulLogin")
//	public String GetSuccessfulLogin()
//	{
//		return "SuccessfulLogin";
//	}
}

