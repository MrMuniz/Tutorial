package com.niit.shoppingcartbe.realdao;

import java.util.List;

import com.niit.shoppingcartbe.model.Category;


public interface CategoryDAO {
	
	
	public List<Category> list();
	
	public Category get(String cid);
	
	public void saveOrUpdate (Category category);
	
	public void delete(String cid);
	

}
