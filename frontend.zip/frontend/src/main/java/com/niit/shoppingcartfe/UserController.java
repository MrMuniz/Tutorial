package com.niit.shoppingcartfe;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller

public class UserController 
{
	@RequestMapping("/")
	public String GetLanding()
	{
		return "Home";
	}

	@RequestMapping("/Home")
	public String GetHome()
	{
		return "Home";
	}

	@RequestMapping("/AboutUs")
	public String GetAboutUs()
	{
		return "AboutUs";
	}

	@RequestMapping("/ContactUs")
	public String GetContactUs()
	{
		return "ContactUs";
	}

	@RequestMapping("/SignUp")
	public String GetSignUp()
	{
		return "SignUp";
	}

	@RequestMapping("/Login")
	public String GetLogin()
	{
		return "Login";
	}

	@RequestMapping("/SuccessfulSignup")
	public String GetSuccessfulSign()
	{
		return "SuccessfulSignup";
	}

	@RequestMapping("/SuccessfulLogin")
	public String GetSuccessfulLogin()
	{
		return "SuccessfulLogin";
	}

}

