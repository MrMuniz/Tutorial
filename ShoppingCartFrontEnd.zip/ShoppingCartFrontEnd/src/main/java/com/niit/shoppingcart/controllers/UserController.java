package com.niit.shoppingcart.controllers;

import javax.persistence.Id;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.niit.shoppingcart.model.Cart;
import com.niit.shoppingcart.model.Category;
import com.niit.shoppingcart.model.Supplier;
import com.niit.shoppingcart.model.User;
import com.niit.shoppingcartDAO.CartDAO;
import com.niit.shoppingcartDAO.CategoryDAO;
import com.niit.shoppingcartDAO.SupplierDAO;
import com.niit.shoppingcartDAO.UserDAO;

@Controller
public class UserController {

	
	

	@Id
	@Autowired
	UserDAO userDAO;
	
	@Autowired
	User user;
	
	@Autowired
	Category category;

	@Autowired
	CategoryDAO categoryDAO;
	
	@Autowired
	Supplier supplier;
	
	@Autowired
	SupplierDAO supplierDAO;
	

	@Autowired
	private CartDAO cartDAO;
	
	@Autowired
	private Cart cart;
	
	
	@RequestMapping("/")
	public ModelAndView onLoad(HttpSession session) {
		//log.debug("Starting of the method onLoad");
		ModelAndView mv = new ModelAndView("/Home");
		session.setAttribute("category", category);
		session.setAttribute("categoryList", categoryDAO.list());
		//log.debug("Ending of the method onLoad");
		return mv;
	}

	
	
	@RequestMapping("/AboutUs")
	public String GetAboutUs()
	{
		return "AboutUs";
	}

	@RequestMapping("/ContactUs")
	public String GetContactUs()
	{
		return "ContactUs";
	}



	@RequestMapping("/SignUp")
	public ModelAndView SignUp() {
		userDAO.saveOrUpdate(user);
		ModelAndView mv = new ModelAndView("/SignUp");
		mv.addObject("user", new User());
		mv.addObject("isUserClickedRegisterHere", "true");
		return mv;
	}
	
	

	@RequestMapping(value="/Login",method=RequestMethod.GET)
	public ModelAndView login(@RequestParam(value="error",required=true)String error,@RequestParam(value="logout",required=false)String logout){
		ModelAndView model=new ModelAndView();
		if(error!=null){
			System.out.println("ERROR.....");
			model.addObject("error", "Invalid Credentials");
		}
		if(logout!=null){
			System.out.println("LOGOUT.....");
			model.addObject("msg", "You have logged out successfully");
		}
		model.setViewName("Login");
		return model;
	}
	
	@RequestMapping(value="user/register", method=RequestMethod.POST)
	public ModelAndView register(@ModelAttribute User user){
		userDAO.saveOrUpdate(user);
		ModelAndView mv=new ModelAndView("/Home");
		mv.addObject("successMessage", "You Have Successfully Registered");
		return mv;
	}
	
	@RequestMapping("/logout")
	public ModelAndView logout(HttpServletRequest request, HttpSession session) {
		ModelAndView mv = new ModelAndView("/Home");
		session.invalidate();
		session = request.getSession(true);
		session.setAttribute("category", category);
		session.setAttribute("categoryList", categoryDAO.list());
	
		mv.addObject("logoutMessage", "You successfully logged out");
		mv.addObject("loggedOut", "true");
	
		return mv;
	 }
	/*@RequestMapping("/Login")
	public String getLogin()
	{
		return "Login";
	}

		
		@RequestMapping("/check")
		public ModelAndView login(@RequestParam (name="name")String id,@RequestParam (name="password")String password)
		{
			ModelAndView mv ;
			boolean isValidUser = userDAO.isValidUser (id, password);
			if (isValidUser == true)
			{
				user = userDAO.get(id);
				
				if (user.isAdmin()==true)
				{				
					mv = new ModelAndView("/Admin");

					mv.addObject("admin", "true");
				}
				else
				{					
					mv = new ModelAndView("/Home");

					mv.addObject("admin", "false");
				}
			}
				else
				{
					mv= new ModelAndView("/Login");
					mv.addObject("invalid credentials", "true");
					mv.addObject("error Message", "invalid credentials");
				}
			
			return mv;
		}*/
	
	@RequestMapping("/Touring")
	public String getTouring()
	{
		return "Touring";
	}
	

	@RequestMapping("/Cruiser")
	public String getCruiser()
	{
		return "Cruiser";
	}	
	
	
	
	
	
	

}
