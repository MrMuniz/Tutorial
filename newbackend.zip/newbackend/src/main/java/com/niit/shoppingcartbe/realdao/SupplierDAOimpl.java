package com.niit.shoppingcartbe.realdao;

import java.util.List;

import javax.persistence.Query;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.shoppingcartbe.model.Supplier;

@Repository("supplierDAO")
public class SupplierDAOimpl implements SupplierDAO	{
	

	@Autowired 
	private SessionFactory sessionFactory;
	
	
	public SupplierDAOimpl (SessionFactory sessionFactory){
		this.sessionFactory = sessionFactory;
	}
	
	
	
	@Transactional
	public void saveOrUpdate(Supplier supplier){
		sessionFactory.getCurrentSession().saveOrUpdate(supplier);
	}

	@Transactional
	public void delete(String Id)
	{
		Supplier supplier = new Supplier();
		supplier.setId(Id);
		sessionFactory.getCurrentSession().delete(supplier);
	}
		
	@Transactional	
	public Supplier get(String Id)
	{
		String hql = "from category where id=" + "'"+ Id+"'";
		
		Query query = sessionFactory.getCurrentSession().createQuery(hql);
		List<Supplier> listsupplier =(List<Supplier>) query.getResultList();
		
		if (listsupplier != null && !listsupplier.isEmpty()){
			return listsupplier.get(0);
		}
		return null;
	}
	
	@Transactional
	public List<Supplier>list(){
		@SuppressWarnings("unchecked")
		List<Supplier> listsupplier = (List<Supplier>)
					sessionFactory.getCurrentSession().createCriteria(Supplier.class).setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();
		return listsupplier;
	}



}
