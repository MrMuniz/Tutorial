package com.niit.shoppingcartfe;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.niit.shoppingcartbe.model.Category;
import com.niit.shoppingcartbe.model.Supplier;
import com.niit.shoppingcartbe.model.User;
import com.niit.shoppingcartbe.realdao.CategoryDAO;
import com.niit.shoppingcartbe.realdao.SupplierDAO;
import com.niit.shoppingcartbe.realdao.UserDAO;





@Controller
public class MainController 
{
	
	@Autowired
	UserDAO userDAO;
	
	@Autowired
	User user;
	
	@Autowired
	Category category;
	
	@Autowired
	CategoryDAO categoryDAO;
	
	@Autowired
	Supplier supplier;
	
	@Autowired
	SupplierDAO supplierDAO;
	
	
	
	@RequestMapping("/")
	public String GetLanding()
	{
		return "Home";
	}

	@RequestMapping("/Home")
	public String GetHome()
	{
		return "Home";
	}

	@RequestMapping("/AboutUs")
	public String GetAboutUs()
	{
		return "AboutUs";
	}

	@RequestMapping("/ContactUs")
	public String GetContactUs()
	{
		return "ContactUs";
	}

	@RequestMapping("/SignUp")
	public String GetSignUp()
	{
		return "SignUp";
	}

	
	@RequestMapping("/Login")
	public String getLogin()
	{
		return "Login";
	}

	@RequestMapping("/Touring")
	public String getTouring()
	{
		return "Touring";
	}	
	
	@RequestMapping("/SuccessfulSignup")
	public String GetSuccessfulSign()
	{
		return "SuccessfulSignup";
	}

	@RequestMapping("/SuccessfulLogin")
	public String GetSuccessfulLogin()
	{
		return "SuccessfulLogin";
	}
}

