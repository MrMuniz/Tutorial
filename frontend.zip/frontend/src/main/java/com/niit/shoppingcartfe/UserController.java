package com.niit.shoppingcartfe;

//import java.util.List;

//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestParam;
//import org.springframework.web.servlet.ModelAndView;
//
//import com.niit.shoppingcartbe.model.Category;
//import com.niit.shoppingcartbe.model.User;
//import com.niit.shoppingcartbe.realdao.CategoryDAO;
//import com.niit.shoppingcartbe.realdao.UserDAO;


public class UserController {
	
//	@Autowired
//	private UserDAO userDAO;
//	@Autowired
//	User user;
//	@Autowired
//	private CategoryDAO categoryDAO;
//	@Autowired
//	private Category category;
//	
//@RequestMapping("/")
//public String getLanding()
//{
//	return "Home";
//}
//@RequestMapping("/AboutUs")
//public String about()
//{
//	return "AboutUs";
//}
//@RequestMapping("/ContactUs")
//public String contact()
//{
//	return "ContactUs";
//}
//@RequestMapping("/Home")
//public String home()
//{
//	return "Home";
//}
//@RequestMapping("/Login")
//public String login()
//{
//	return "Login";
//}
//	
//	@RequestMapping("/check")
//	public ModelAndView login(@RequestParam (name="name")String id,@RequestParam (name="password")String password)
//	{
//		ModelAndView mv = new ModelAndView("/Admin");
//		boolean isValidUser = userDAO.isValidUser (id, password);
//		if (isValidUser == true)
//		{
//			user = userDAO.get(id);
//			
//			if (user.getAdmin()==true)
//			{
//				mv.addObject("admin", "true");
//			}
//			else
//			{
//				mv.addObject("admin", "false");
//			}
//		}
//			else
//			{
//				mv.addObject("invalid credentials", "true");
//				mv.addObject("error Message", "invalid credentials");
//			}
//		
//		return mv;
//	}
//
//
//@RequestMapping("/SignUp")
//public String getsignup()
//{
//	return "SignUp";
//}
}
