package com.practice.work;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;


import com.niit.shoppingcartbe.model.Product;

import com.niit.shoppingcartbe.realdao.ProductDAO;

public class ProductTest {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();

		context.scan("com.niit.shoppingcartbe");
		context.refresh();

		ProductDAO productDAO = (ProductDAO) context.getBean("productDAO");
		Product product = (Product) context.getBean("product");

		product.setPid(005);
		product.setCat(05);
		product.setName("Triumph");
		product.setPrice(60000);
		product.setSupplier(174);

		productDAO.saveOrUpdate(product);
	}

}
