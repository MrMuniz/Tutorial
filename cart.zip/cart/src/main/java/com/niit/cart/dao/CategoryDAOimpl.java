package com.niit.cart.dao;

import java.util.List;



import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.cart.model.Category;


@Repository("categoryDAO")
public class CategoryDAOimpl implements CategoryDAO {
		
	
		@Autowired 
		private SessionFactory sessionFactory;
		
		
		public CategoryDAOimpl (SessionFactory sessionFactory){
			this.sessionFactory = sessionFactory;
		}
		
		
		
		@Transactional
		public void saveOrUpdate(Category category){
			sessionFactory.getCurrentSession().saveOrUpdate(category);
		}

		@Transactional
		public void delete(String cid)
		{
			Category category = new Category();
			category.setCid(cid);
			sessionFactory.getCurrentSession().delete(category);
		}
			
		@Transactional	
		public Category get(String cid)
		{
			String hql = "from category where id=" + "'"+ cid+"'";
			
			Query query = sessionFactory.getCurrentSession().createQuery(hql);
			List<Category> listcategory =(List<Category>) query.getResultList();
			
			if (listcategory != null && !listcategory.isEmpty()){
				return listcategory.get(0);
			}
			return null;
		}
		
		@Transactional
		public List<Category>list(){
			@SuppressWarnings("unchecked")
			List<Category> listCategory = (List<Category>)
						sessionFactory.getCurrentSession().createCriteria(Category.class).setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();
			return listCategory;
		}





















}
