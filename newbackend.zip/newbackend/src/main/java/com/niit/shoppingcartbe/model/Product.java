package com.niit.shoppingcartbe.model;

import javax.persistence.Entity;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity
@Table(name = "Product")
@Component
public class Product {
	
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public int getPrice() {
		return Price;
	}
	public void setPrice(int price) {
		Price = price;
	}
	public int getPid() {
		return Pid;
	}
	public void setPid(int pid) {
		Pid = pid;
	}
	public int getCat() {
		return Cat;
	}
	public void setCat(int cat) {
		Cat = cat;
	}
	public int getSupplier() {
		return Supplier;
	}
	public void setSupplier(int supplier) {
		Supplier = supplier;
	}
	private String Name;
	private int Price;
	private int Pid;
	private int Cat;
	private int Supplier;
}
