package com.niit.shoppingcartbe.realdao;

import java.util.List;

import com.niit.shoppingcartbe.model.User;

public interface UserDAO {
	
	public List<User> list();
	
	public User get(String Username);
	
	public void saveOrUpdate (User user);
	
	public void delete(String Username);
	
	public boolean isValidUser(String password, String username);
}
