package com.niit.shoppingcartfe;

//import org.eclipse.jdt.internal.compiler.ast.EqualExpression;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.ui.Model;
//import org.springframework.ui.ModelMap;
//import org.springframework.web.bind.annotation.ModelAttribute;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestMethod;
//
//import com.niit.shoppingcartbe.model.Category;
//import com.niit.shoppingcartbe.realdao.CategoryDAO;
//import com.niit.shoppingcartbe.util.Util;

public class CategoryController {

//	@Autowired
//	private CategoryDAO categoryDAO;
//
//	@Autowired
//	private Category category;
//
//	@RequestMapping(value = "/categories", method = RequestMethod.GET)
//	public String listCategories(Model model) {
//		model.addAttribute("category", category);
//		model.addAttribute("categoryList", this.categoryDAO.list());
//		return "Categories";
//	}
//
//	 
//	@RequestMapping(value="/Categories/add",method=RequestMethod.POST)
//	public String addCategory(@ModelAttribute("Categories") Category category) {
//
//		Util util = new Util();
//		String id = util.replace(category.getCid(), ",", "");
//		category.setCname(id);
//
//		categoryDAO.saveOrUpdate(category);
//
//		 return "redirect:/category";
//		//return "categories";
//
//	}
//
//	@RequestMapping("Categories/remove/{id}")
//	public String deleteCategory(@PathVariable("id") String cid, ModelMap model) throws Exception {
//
//		try {
//			categoryDAO.delete(cid);
//			model.addAttribute("message", "Successfully Added");
//		} catch (Exception e) {
//			model.addAttribute("message", e.getMessage());
//			e.printStackTrace();
//		}
//		  // redirectAttrs.addFlashAttribute(arg0, arg1)
//		return "redirect:/Categories";
//	}
//
//	@RequestMapping("Categories/edit/{id}")
//	public String editCategory(@PathVariable("id") String cid, Model model) {
//		System.out.println("editCategory");
//		model.addAttribute("category", this.categoryDAO.get(cid));
//		model.addAttribute("listCategorys", this.categoryDAO.list());
//		return "Categories";
//	}

}
